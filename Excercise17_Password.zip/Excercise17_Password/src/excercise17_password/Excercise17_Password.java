

// Name: Mervin Thomas
// Instructor Name: Kyle Batterink 
// Course: ICS4U 
// Due Date: February 13, 2017



/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


package excercise17_password;

import java.util.Scanner; 

/**
 *
 * @author Mervin
 */
public class Excercise17_Password {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        String password = "computerscience";// This line of code allows the program to set the password in the form of a string
        
        Scanner input = new Scanner(System.in); //allows input for the user 
        
        int incorrectGuesses = 0;//Sets the number of correct guess to zero in order to initialize it
        
        while(true){//runs until the commmand structure is broken
            
            System.out.println("Enter the password: ");//Asks the user for the input of their password 
            
            String guess = input.nextLine();//This line of code stores the input of the user into the guesses. 
            
            if(guess.equals(password)){//This line of code allows the user acess if the guess is correct
                
                System.out.println("Welcome, you have gained access!");//prints that you have been allowed
                
                break;
           
            }else
            {
                incorrectGuesses += 1; //This line of code counts the number of times each guess is incorrec. 
                
                System.out.println("The password you entered was incorrect.");//sks the user to enter password again
                
                if(incorrectGuesses==3){// Access is denied if the incorrect guesses is done three times. 
                   
                    System.out.println("Access denied.");//Prints out access is denied if the user types the wrong password for three times. 
                    
                    break;//Breaks the line of code and ends the program. 
                }
        
       
        
       
    }
    
}
            }
    
}
