// Name: Mervin Thomas
// Instructor Name: Kyle Batterink 
// Course: ICS4U 
// Due Date: February 13, 2017


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package excercise18monogram;
import java.util.Scanner;
/**
 *
 * @author Lab26
 */
public class Excercise18monogram {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("Please enter your first name: ");//Asks user for input
        
        String firstName = input.nextLine();//This line of code stores the first input into this variable
        
        System.out.println("Please enter your middle initial: ");//Prompts user for the second input
        
        String middleInitial = input.nextLine();//This line of code store middle name into variable
        
        System.out.println("Please enter your last name: ");//Prompts user for the third input
        
        String lastName = input.nextLine();//stores the third input into variable
        
        String firstLetter = firstName.substring(0, 1).toLowerCase();//This lineof code stores the first eltter of the first word into the firstletter vairable
        
        String middleLetter = middleInitial.toLowerCase();//stores middle initial in middleLetter variable which is in lower case
        
        String lastLetter = lastName.substring(0,1).toUpperCase();//stores first letter of Lastname in lastLetter variable which is in upper case
        
        System.out.println("");//This line of code adds a space line
        System.out.println("Your monogram is: "+firstLetter+lastLetter+middleLetter);//Prints the monogram with the help of the variables and the code.
        
        // TODO code application logic here
    }
    
}
