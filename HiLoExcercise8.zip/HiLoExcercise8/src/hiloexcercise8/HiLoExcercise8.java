
// Name: Mervin Thomas
// Instructor Name: Kyle Batterink 
// Course: ICS4U 
// Due Date: February 28, 2017

package hiloexcercise8;

import java.util.Scanner;

/**
 *
 * @author Mervin
 */
public class HiLoExcercise8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
            
    Scanner input = new Scanner(System.in).useDelimiter("\n");
    
    System.out.println("High Low Game\n\nNumbers 1 though 6 are low.\nNumbers 7 though 13 are high.\nYou have 1000 points.\n");//displays game instructions and points
    
    int points = 1000; //Sets the variable "points" to 1000. 
    
    int tries = 0;// Sets the variable "tries" to 0 
    
        while(points > 0){//while the player has more than 0 points,
            
            System.out.print("Enter points to risk: ");//Asks the user for the points they are willing to risk. 
            
            int randomNumber = (int)((13-1+1)*Math.random()+1); //This line of code generated random numbers from 1-13. 
            
            int riskpoints = input.nextInt();//stores input into variable "riskpoints"
            
            System.out.print("Enter 1 to predict HIGH, Enter 2 to predict LOW: ");//This line of code displays options for entering high or low
            
            int highorlow = input.nextInt();//stores input into variable "highorlow" to be stored for the later use. 

            System.out.println("\nNumber is " + randomNumber);//This line of code displays the secret number. 
            
            if(((randomNumber > 6) && (highorlow == 1)) || ((randomNumber < 7) && (highorlow == 0))){//If command that checks if the user guesses correctly if high or low.
               
                System.out.println("\nYou win!"); // Prints out the "you win" if the for loop condition is met. 
                
                points += riskpoints;//Adds the points risked. 
            }
            else{//if incorrect or against the system,
                
                System.out.println("\nYou lose.");
                
                points -= riskpoints;//removes the points risked from the amount of points if user loses
            }
            System.out.println("You now have " + points + " points."); //displays current points the user has
            
            tries+=1;//adds to the amount of tries previosly created in the program. 
        }
        
        System.out.println("GAME OVER after "+tries+" tries."); //Prints game over and finishes the game if tries are over. 
    }
    }
    

