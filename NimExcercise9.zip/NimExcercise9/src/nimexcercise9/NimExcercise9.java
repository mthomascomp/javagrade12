

// Name: Mervin Thomas
// Instructor Name: Kyle Batterink 
// Course: ICS4U 
// Due Date: February 28, 2017

package nimexcercise9;

import java.util.Scanner;

/**
 *
 * @author Mervin
 */
public class NimExcercise9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        int stonepile = (int)((29-16+1)*Math.random()+16);//creates a random number between 15-30 for the size of the ston pile
        
        while(true){//This while loop runs until break
            
            System.out.print("There are "+stonepile+" stones. How many would you like? ");//Displays the current number of stones avaible to prompt user to choose one. 
           
            Scanner input = new Scanner(System.in).useDelimiter("\n");
            
            int stones = input.nextInt();//sets input to variable stones
            
            int ComputerStones = drawStones();//uses the drawStones method to pick a number 
            
            if(isValidEntry(stones, stonepile) == false){//The loop breaks and the computer wins if the number of stones are not valid. 
            
                System.out.println("The computer beats the player!");
                
                break;
            }
            
            stonepile -= stones;// This line of code removes user's stones requested from the stone pile
            
            System.out.println("There are "+stonepile+" stones. The computer takes " +ComputerStones+ " stones.");//This line of code displays the turn of the computer
            
            if(isValidEntry(ComputerStones,stonepile) == false){//if the computers stones requested is not valid, the computer wins and loop breaks
            
                System.out.println("The player beats the computer!");
                
                break;
            }
            
            stonepile -= ComputerStones;//removes the number of stones requested by the computer pile. 
        }  
    }
    public static boolean isValidEntry(int stonesRequested, int amountOfStones){//takes the inputs of the stones requested and stones in the pile ad checks if request is valid
       
        if((stonesRequested < 0)||(stonesRequested > 3)){//prints error and returns false if the number is not 1, 2 or 3
        
            System.out.print("You must take 1, 2, or 3 stones! ");
            
            return(false);
        }
        else if(stonesRequested >= amountOfStones){//returns false if more or an equal amount is requested from the stone pile
       
            return(false);
        }
        else{//returns true if the input is valid as per the code
        
            return(true);
        }
    }
    public static int drawStones(){//This line of code returns random integer between 1-3
        
        return (int)((3-1+1)*Math.random()+1);  
    }
        
    }
    

