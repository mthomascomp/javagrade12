/**
 *
 * @author Mervin Thomas
 */

// Name: Mervin Thomas
// Instructor Name: Kyle Batterink 
// Course: ICS4U 
// Due Date: February 8, 2016 

package eightaandb;


import java.util.Scanner;//imports from the java library. 
import java.lang.Math; //Imports math commands 

public class EightAandB {
    
    public static void main(String[] args) {
        
        
        int randomNumber = (int)((20-1+1)*Math.random()+1); //Automatically generates a random number from 1-20
        
        Scanner input = new Scanner(System.in); //Input from the user 
        
        int guess = 0;//defined guess variable and set to 0 
        
        while(true){// This is a while loop and it loops until the command is broken. 
            
            System.out.println("Please Enter a number that is between 1 and 20:");//System out command which siplays the string to the user. 
            
            guess = input.nextInt();//allows for input
            
            if(guess == randomNumber)
            {
                break;//This allows for the loop to exist until the guess is correct.
            }
            System.out.println("Please Try again.");//This command prints try again if the answer is not correct. 
        }
        System.out.println("You Have Won !");//prints you win after the break occurs if the  guessed answer is correct
    }
}
