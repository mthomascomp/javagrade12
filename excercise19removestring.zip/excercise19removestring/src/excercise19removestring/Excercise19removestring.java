// Name: Mervin Thomas
// Instructor Name: Kyle Batterink 
// Course: ICS4U 
// Due Date: February 13, 2017


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package excercise19removestring;
import java.util.Scanner; 
/**
 *
 * @author Lab26
 */
public class Excercise19removestring {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in); //Allows for user inputs 
        System.out.println("Please Enter a sentence: ");//Prints the line of code to be used. 
        String sentence = input.nextLine();//Stores the input in string format
        System.out.println("Enter a string (a word from the sentenced typed above: ");//Prints the line of code to be used. 
        String word = input.nextLine();//Stores the second input in string format
        String newSentence = sentence.replaceFirst(word+" ", "");//Cuts the desired string of the user
        System.out.println(newSentence);//Prints the final statement.
    }
    
}
