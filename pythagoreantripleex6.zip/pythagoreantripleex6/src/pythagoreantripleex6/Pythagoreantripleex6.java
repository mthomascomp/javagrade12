
// Name: Mervin Thomas
// Instructor Name: Kyle Batterink 
// Course: ICS4U 
// Due Date: February 28, 2017


package pythagoreantripleex6;

/**
 *
 * @author Mervin
 */
public class Pythagoreantripleex6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
    for(int a = 1;a < 100;a++){//This line of code runs the pythagoream method for all integers from 0-100.  
        
        
            for(int b = 1;b < 100;b++){// For loop that executes the command within the brackets. 
                
                
                    pythagoream(a,b);   
            }
        }     
    }
    public static void pythagoream(int a,int b){
        
        double c = Math.sqrt(a*a + b*b);//Allows a variable c to exist which will be square rooted by a square and b square
        
        if((c == (int)c) && ((a*a + b*b) == (c*c))){//if c is an integer and a squared plus b squared is equal to c squared, it prints the three in a sentence
            
            System.out.println(a + " " + b + " " + (int)c);// Print out command that is made of the answers constitued in the previous lines of code. 
        }
    }
    
}
   
    

